

#ifndef _IPA_QDSS_H_
#define _IPA_QDSS_H_

#include <linux/ipa.h>


enum ipa_qdss_notify {
	IPA_QDSS_SUCCESS,
	IPA_QDSS_PIPE_CONN_FAILURE,
	IPA_QDSS_PIPE_DISCONN_FAILURE,
};


struct ipa_qdss_conn_in_params {
	phys_addr_t  data_fifo_base_addr;
	u32  data_fifo_size;
	phys_addr_t desc_fifo_base_addr;
	u32 desc_fifo_size;
	phys_addr_t  bam_p_evt_dest_addr;
	u32 bam_p_evt_threshold;
	u32 override_eot;
};


struct ipa_qdss_conn_out_params {
	phys_addr_t ipa_rx_db_pa;
};

#if defined CONFIG_IPA3


int ipa_qdss_conn_pipes(struct ipa_qdss_conn_in_params *in,
	struct ipa_qdss_conn_out_params *out);


int ipa_qdss_disconn_pipes(void);

#else 

static inline int ipa_qdss_conn_pipes(struct ipa_qdss_conn_in_params *in,
	struct ipa_qdss_conn_out_params *out)
{
	return -IPA_QDSS_PIPE_CONN_FAILURE;
}

static inline int ipa_qdss_disconn_pipes(void)
{
	return -IPA_QDSS_PIPE_DISCONN_FAILURE;
}

#endif 
#endif 
