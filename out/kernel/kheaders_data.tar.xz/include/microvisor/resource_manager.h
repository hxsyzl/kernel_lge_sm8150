


#define ERROR_REPLY 0x8000ffff


#define BOOT_MGR_PROTOCOL_ID 'B'


#define BOOT_MGR_START_CLIENT 0x00420001


struct boot_mgr_start_params {
    uint64_t entry_addr; 
    uint64_t dtb_addr; 
    bool is_64bit; 
};


#define BOOT_MGR_START_CLIENT_REPLY 0x80420001



#define BOOT_MGR_START_SELF 0x00420002



#define BOOT_MGR_START_SELF_REPLY 0x80420002




#define RES_MGR_SECURECAM_SERVER_PROTOCOL_ID 'q'


#define RES_MGR_SECURECAM_GET_HANDLE 0x00710001

struct res_mgr_region {
    uint64_t address_ipa;
    uint64_t size;
};

struct res_mgr_sglist {
    uint32_t region_count;
    struct res_mgr_region regions[];
};


#define RES_MGR_SECURECAM_GET_HANDLE_REPLY 0x80710001


#define RES_MGR_SECURECAM_DESTROY_HANDLES 0x00710002


#define RES_MGR_SECURECAM_DESTROY_HANDLES_REPLY 0x80710002



#define RES_MGR_SECURECAM_CLIENT_PROTOCOL_ID 'Q'


#define RES_MGR_SECURECAM_NOTIFY_START 0x80510001


#define RES_MGR_SECURECAM_ACK_START 0x00510001


#define RES_MGR_SECURECAM_DONE 0x00510002


#define RES_MGR_LOOKUP_HANDLE 0x00510003


#define RES_MGR_LOOKUP_HANDLE_REPLY 0x80510003


#define RES_MGR_SECURECAM_NOTIFY_STOP 0x80510004


#define RES_MGR_SECURECAM_ACK_STOP 0x00510004


struct res_mgr_msg {
    uint32_t msg_id;
    union {
        bool success;
        struct {
            struct boot_mgr_start_params start_params;
        } boot_mgr;
        struct {
            uint32_t handle;
            struct res_mgr_sglist sglist;
        } securecam;
    };
};
