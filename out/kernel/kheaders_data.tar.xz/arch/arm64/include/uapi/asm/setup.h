/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */

#ifndef __ASM_SETUP_H
#define __ASM_SETUP_H

#include <linux/types.h>

#ifdef CONFIG_MACH_LGE
#define COMMAND_LINE_SIZE	4096
#else
#define COMMAND_LINE_SIZE	2048
#endif

#endif
